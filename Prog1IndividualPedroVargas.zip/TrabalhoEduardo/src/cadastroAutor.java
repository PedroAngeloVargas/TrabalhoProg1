import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

/*Cadastrar Autor */
public class cadastroAutor {
    private JFrame frame;
    private JTextField nome, nacionalidade;
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton saveButton;
    private int selectedRow = -1;

    public cadastroAutor(JFrame telaInicial) {
        frame = new JFrame("Cadastro de Autor");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1600, 1200);
        frame.setLocationRelativeTo(null);

        // Painel de entrada
        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Nome:"));
        nome = new JTextField();
        panel.add(nome);

        panel.add(new JLabel("Nacionalidade:"));
        nacionalidade = new JTextField();
        panel.add(nacionalidade);

        JButton addButton = new JButton("Adicionar Autor");
        saveButton = new JButton("Salvar Edição");
        saveButton.setEnabled(false); // Desativado até selecionar um autor para edição
        JButton editButton = new JButton("Editar Autor");
        JButton deleteButton = new JButton("Excluir Autor");
        JButton voltarButton = new JButton("Voltar");

        panel.add(addButton);
        panel.add(saveButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(voltarButton);

        // Criando a tabela
        tableModel = new DefaultTableModel(new Object[]{"Nome", "Nacionalidade"}, 0);
        table = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(table);

        // Adicionando componentes ao frame
        frame.add(panel, BorderLayout.NORTH);
        frame.add(tableScrollPane, BorderLayout.CENTER);

        // Ações dos botões
        addButton.addActionListener((ActionEvent e) -> adicionarAutor());
        editButton.addActionListener((ActionEvent e) -> carregarDadosParaEdicao());
        saveButton.addActionListener((ActionEvent e) -> salvarEdicao());
        deleteButton.addActionListener((ActionEvent e) -> excluirAutor());

        voltarButton.addActionListener((ActionEvent e) -> {
            frame.dispose();
            telaInicial.setVisible(true);
        });

        frame.setVisible(true);
    }

    private void adicionarAutor() {
        String nomeTexto = nome.getText();
        String nacionalidadeTexto = nacionalidade.getText();

        if (!nomeTexto.isEmpty() && !nacionalidadeTexto.isEmpty()) {
            tableModel.addRow(new Object[]{nomeTexto, nacionalidadeTexto});
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(frame, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDadosParaEdicao() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            nome.setText((String) tableModel.getValueAt(selectedRow, 0));
            nacionalidade.setText((String) tableModel.getValueAt(selectedRow, 1));
            saveButton.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um autor para editar!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void salvarEdicao() {
        if (selectedRow != -1) {
            tableModel.setValueAt(nome.getText(), selectedRow, 0);
            tableModel.setValueAt(nacionalidade.getText(), selectedRow, 1);
            limparCampos();
            saveButton.setEnabled(false);
            selectedRow = -1;
        }
    }

    private void excluirAutor() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir este autor?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
                limparCampos();
                selectedRow = -1;
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um autor para excluir!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limparCampos() {
        nome.setText("");
        nacionalidade.setText("");
    }
}
