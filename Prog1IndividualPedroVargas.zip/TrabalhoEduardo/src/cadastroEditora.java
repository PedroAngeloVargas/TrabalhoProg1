import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/*Cadastrar Editora */
public class cadastroEditora {
    private JFrame frame;
    private JTextField nomeFantasia, razaoSocial, cnpj, inscricaoEstadual, email, telefone;
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton saveButton;
    private int selectedRow = -1;

    public cadastroEditora() {
        frame = new JFrame("Cadastro de Editoras");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1600, 1200);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(9, 2));
        panel.add(new JLabel("Nome Fantasia:"));
        nomeFantasia = new JTextField();
        panel.add(nomeFantasia);

        panel.add(new JLabel("Razão Social:"));
        razaoSocial = new JTextField();
        panel.add(razaoSocial);

        panel.add(new JLabel("CNPJ:"));
        cnpj = new JTextField();
        cnpj.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) {
                    e.consume();
                }
            }
        });
        panel.add(cnpj);

        panel.add(new JLabel("Inscrição Estadual:"));
        inscricaoEstadual = new JTextField();
        inscricaoEstadual.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) {
                    e.consume();
                }
            }
        });
        panel.add(inscricaoEstadual);

        panel.add(new JLabel("E-mail:"));
        email = new JTextField();
        panel.add(email);

        panel.add(new JLabel("Telefone:"));
        telefone = new JTextField();
        panel.add(telefone);

        JButton addButton = new JButton("Adicionar Editora");
        saveButton = new JButton("Salvar Edição");
        saveButton.setEnabled(false);
        JButton editButton = new JButton("Editar Editora");
        JButton deleteButton = new JButton("Excluir Editora");
        JButton voltarButton = new JButton("Voltar");

        panel.add(addButton);
        panel.add(saveButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(voltarButton);

        frame.add(panel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"Nome Fantasia", "Razão Social", "CNPJ", "Inscrição Estadual", "E-mail", "Telefone"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(e -> adicionarEditora());
        editButton.addActionListener(e -> carregarDadosParaEdicao());
        saveButton.addActionListener(e -> salvarEdicao());
        deleteButton.addActionListener(e -> excluirEditora());

        voltarButton.addActionListener(e -> frame.dispose());

        frame.setVisible(true);
    }

    private void adicionarEditora() {
        String nomeFantasia = this.nomeFantasia.getText();
        String razaoSocial = this.razaoSocial.getText();
        String cnpj = this.cnpj.getText();
        String inscricaoEstadual = this.inscricaoEstadual.getText();
        String email = this.email.getText();
        String telefone = this.telefone.getText();

        if (!nomeFantasia.isEmpty() && !razaoSocial.isEmpty() && !cnpj.isEmpty() && !inscricaoEstadual.isEmpty() && !email.isEmpty() && !telefone.isEmpty()) {
            tableModel.addRow(new Object[]{nomeFantasia, razaoSocial, cnpj, inscricaoEstadual, email, telefone});
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(frame, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDadosParaEdicao() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            nomeFantasia.setText((String) tableModel.getValueAt(selectedRow, 0));
            razaoSocial.setText((String) tableModel.getValueAt(selectedRow, 1));
            cnpj.setText((String) tableModel.getValueAt(selectedRow, 2));
            inscricaoEstadual.setText((String) tableModel.getValueAt(selectedRow, 3));
            email.setText((String) tableModel.getValueAt(selectedRow, 4));
            telefone.setText((String) tableModel.getValueAt(selectedRow, 5));
            saveButton.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione uma editora para editar!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void salvarEdicao() {
        if (selectedRow != -1) {
            tableModel.setValueAt(nomeFantasia.getText(), selectedRow, 0);
            tableModel.setValueAt(razaoSocial.getText(), selectedRow, 1);
            tableModel.setValueAt(cnpj.getText(), selectedRow, 2);
            tableModel.setValueAt(inscricaoEstadual.getText(), selectedRow, 3);
            tableModel.setValueAt(email.getText(), selectedRow, 4);
            tableModel.setValueAt(telefone.getText(), selectedRow, 5);
            limparCampos();
            saveButton.setEnabled(false);
            selectedRow = -1;
        }
    }

    private void excluirEditora() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir esta editora?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
                limparCampos();
                selectedRow = -1;
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione uma editora para excluir!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limparCampos() {
        nomeFantasia.setText("");
        razaoSocial.setText("");
        cnpj.setText("");
        inscricaoEstadual.setText("");
        email.setText("");
        telefone.setText("");
    }
}
