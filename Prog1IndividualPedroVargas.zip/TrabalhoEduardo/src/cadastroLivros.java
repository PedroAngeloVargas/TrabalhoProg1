import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/*Cadastrar Livros */
public class cadastroLivros {
    private JFrame frame;
    private JTextField titulo, genero, autor, ano, editora;
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton saveButton;
    private int selectedRow = -1;

    public cadastroLivros() {
        frame = new JFrame("Cadastro de Livros");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1600, 1200);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2));
        panel.add(new JLabel("Título:"));
        titulo = new JTextField();
        panel.add(titulo);

        panel.add(new JLabel("Gênero:"));
        genero = new JTextField();
        panel.add(genero);

        panel.add(new JLabel("Autor:"));
        autor = new JTextField();
        panel.add(autor);

        panel.add(new JLabel("Ano:"));
        ano = new JTextField();
        ano.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) {
                    e.consume();
                }
            }
        });
        panel.add(ano);

        panel.add(new JLabel("Editora:"));
        editora = new JTextField();
        panel.add(editora);

        JButton addButton = new JButton("Adicionar Livro");
        JButton editButton = new JButton("Editar Livro");
        saveButton = new JButton("Salvar Alterações");
        saveButton.setEnabled(false);
        JButton deleteButton = new JButton("Excluir Livro");
        JButton voltarButton = new JButton("Voltar");

        panel.add(addButton);
        panel.add(editButton);
        panel.add(saveButton);
        panel.add(deleteButton);
        panel.add(voltarButton);

        frame.add(panel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"Título", "Gênero", "Autor", "Ano", "Editora"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(e -> addLivro());
        editButton.addActionListener(e -> carregarDadosParaEdicao());
        saveButton.addActionListener(e -> salvarEdicao());
        deleteButton.addActionListener(e -> excluirLivro());
        voltarButton.addActionListener(e -> frame.dispose());

        frame.setVisible(true);
    }

    private void addLivro() {
        String t = titulo.getText();
        String g = genero.getText();
        String a = autor.getText();
        String an = ano.getText();
        String e = editora.getText();

        if (validarCampos(t, g, a, an, e)) {
            tableModel.addRow(new Object[]{t, g, a, an, e});
            limparCampos();
        }
    }

    private void carregarDadosParaEdicao() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            titulo.setText((String) tableModel.getValueAt(selectedRow, 0));
            genero.setText((String) tableModel.getValueAt(selectedRow, 1));
            autor.setText((String) tableModel.getValueAt(selectedRow, 2));
            ano.setText((String) tableModel.getValueAt(selectedRow, 3));
            editora.setText((String) tableModel.getValueAt(selectedRow, 4));
            saveButton.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um livro para editar!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void salvarEdicao() {
        if (selectedRow != -1) {
            String t = titulo.getText();
            String g = genero.getText();
            String a = autor.getText();
            String an = ano.getText();
            String e = editora.getText();

            if (validarCampos(t, g, a, an, e)) {
                tableModel.setValueAt(t, selectedRow, 0);
                tableModel.setValueAt(g, selectedRow, 1);
                tableModel.setValueAt(a, selectedRow, 2);
                tableModel.setValueAt(an, selectedRow, 3);
                tableModel.setValueAt(e, selectedRow, 4);
                limparCampos();
                saveButton.setEnabled(false);
                selectedRow = -1;
            }
        }
    }

    private void excluirLivro() {
        int row = table.getSelectedRow();
        if (row != -1) {
            int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir este livro?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(row);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um livro para excluir!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limparCampos() {
        titulo.setText("");
        genero.setText("");
        autor.setText("");
        ano.setText("");
        editora.setText("");
    }

    private boolean validarCampos(String titulo, String genero, String autor, String ano, String editora) {
        if (titulo.isEmpty() || genero.isEmpty() || autor.isEmpty() || ano.isEmpty() || editora.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}
