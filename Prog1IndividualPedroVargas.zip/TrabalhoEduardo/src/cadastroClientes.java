import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

/*Cadastrar Clientes */
public class cadastroClientes {
    private JFrame frame;
    private JTextField nome, cpf, dataNascimento, telefone, email, cep, cidade, uf, rua, bairro, numero, complemento;
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton saveButton;
    private int selectedRow = -1;

    public cadastroClientes(JFrame mainFrame) {
        frame = new JFrame("Cadastro de Clientes");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1600, 1200);

        JPanel panel = new JPanel(new GridLayout(15, 2));
        panel.add(new JLabel("Nome:"));
        nome = new JTextField();
        panel.add(nome);

        panel.add(new JLabel("CPF:"));
        cpf = new JTextField();
        cpf.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar()) || cpf.getText().length() >= 11) {
                    e.consume();
                }
            }
        });
        panel.add(cpf);

        panel.add(new JLabel("Data de Nascimento (DD/MM/AAAA):"));
        dataNascimento = new JTextField();
        dataNascimento.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ((!Character.isDigit(c) && c != '/') || dataNascimento.getText().length() >= 10) {
                    e.consume();
                }
            }
        });
        panel.add(dataNascimento);

        panel.add(new JLabel("Telefone:"));
        telefone = new JTextField();
        telefone.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) {
                    e.consume();
                }
            }
        });
        panel.add(telefone);

        panel.add(new JLabel("Email:"));
        email = new JTextField();
        panel.add(email);

        panel.add(new JLabel("CEP:"));
        cep = new JTextField();
        cep.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar()) || cep.getText().length() >= 8) {
                    e.consume();
                }
            }
        });
        panel.add(cep);

        panel.add(new JLabel("Cidade:"));
        cidade = new JTextField();
        panel.add(cidade);

        panel.add(new JLabel("UF:"));
        uf = new JTextField();
        uf.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (uf.getText().length() >= 2) {
                    e.consume();
                }
            }
        });
        panel.add(uf);

        panel.add(new JLabel("Rua:"));
        rua = new JTextField();
        panel.add(rua);

        panel.add(new JLabel("Bairro:"));
        bairro = new JTextField();
        panel.add(bairro);

        panel.add(new JLabel("Número:"));
        numero = new JTextField();
        numero.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) {
                    e.consume();
                }
            }
        });
        panel.add(numero);

        panel.add(new JLabel("Complemento:"));
        complemento = new JTextField();
        panel.add(complemento);

        JButton addButton = new JButton("Adicionar Cliente");
        saveButton = new JButton("Salvar Edição");
        saveButton.setEnabled(false);
        JButton editButton = new JButton("Editar Cliente");
        JButton deleteButton = new JButton("Excluir Cliente");
        JButton voltarButton = new JButton("Voltar");

        panel.add(addButton);
        panel.add(saveButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(voltarButton);

        frame.add(panel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"Nome", "CPF", "Data de Nascimento", "Telefone", "Email", "CEP", "Cidade", "UF", "Rua", "Bairro", "Número", "Complemento"}, 0);
        table = new JTable(tableModel);
        frame.add(new JScrollPane(table), BorderLayout.CENTER);

        addButton.addActionListener(e -> adicionarCliente());
        editButton.addActionListener(e -> carregarDadosParaEdicao());
        saveButton.addActionListener(e -> salvarEdicao());
        deleteButton.addActionListener(e -> excluirCliente());
        voltarButton.addActionListener(e -> {
            frame.dispose();
            mainFrame.setVisible(true);
        });

        frame.setVisible(true);
    }

    private void adicionarCliente() {
        String[] dados = {nome.getText(), cpf.getText(), dataNascimento.getText(), telefone.getText(), email.getText(),
                cep.getText(), cidade.getText(), uf.getText(), rua.getText(), bairro.getText(), numero.getText(), complemento.getText()};
        
        for (String campo : dados) {
            if (campo.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Preencha todos os campos obrigatórios!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        tableModel.addRow(dados);
        limparCampos();
    }
    private void carregarDadosParaEdicao() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            nome.setText((String) tableModel.getValueAt(selectedRow, 0));
            cpf.setText((String) tableModel.getValueAt(selectedRow, 1));
            dataNascimento.setText((String) tableModel.getValueAt(selectedRow, 2));
            telefone.setText((String) tableModel.getValueAt(selectedRow, 3));
            email.setText((String) tableModel.getValueAt(selectedRow, 4));
            cep.setText((String) tableModel.getValueAt(selectedRow, 5));
            cidade.setText((String) tableModel.getValueAt(selectedRow, 6));
            uf.setText((String) tableModel.getValueAt(selectedRow, 7));
            rua.setText((String) tableModel.getValueAt(selectedRow, 8));
            bairro.setText((String) tableModel.getValueAt(selectedRow, 9));
            numero.setText((String) tableModel.getValueAt(selectedRow, 10));
            complemento.setText((String) tableModel.getValueAt(selectedRow, 11));
    
            saveButton.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um cliente para editar!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void salvarEdicao() {
        if (selectedRow != -1) {
            tableModel.setValueAt(nome.getText(), selectedRow, 0);
            tableModel.setValueAt(cpf.getText(), selectedRow, 1);
            tableModel.setValueAt(dataNascimento.getText(), selectedRow, 2);
            tableModel.setValueAt(telefone.getText(), selectedRow, 3);
            tableModel.setValueAt(email.getText(), selectedRow, 4);
            tableModel.setValueAt(cep.getText(), selectedRow, 5);
            tableModel.setValueAt(cidade.getText(), selectedRow, 6);
            tableModel.setValueAt(uf.getText(), selectedRow, 7);
            tableModel.setValueAt(rua.getText(), selectedRow, 8);
            tableModel.setValueAt(bairro.getText(), selectedRow, 9);
            tableModel.setValueAt(numero.getText(), selectedRow, 10);
            tableModel.setValueAt(complemento.getText(), selectedRow, 11);
    
            limparCampos();
            saveButton.setEnabled(false);
            selectedRow = -1;
        }
    }
    

    private void excluirCliente() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir este cliente?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
                limparCampos();
                selectedRow = -1;
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um cliente para excluir!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limparCampos() {
        for (Component c : frame.getContentPane().getComponents()) {
            if (c instanceof JTextField) {
                ((JTextField) c).setText("");
            }
        }
    }
}
