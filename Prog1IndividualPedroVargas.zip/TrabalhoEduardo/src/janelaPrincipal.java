import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;

/*Software de cadastro e listagem para uma biblioteca 
 * @author Pedro Angelo Tellaroli Vargas
*/
/*Janela Principal do software */
public class janelaPrincipal {
    private JFrame frame;

    public janelaPrincipal() {
        frame = new JFrame("Sistema de Biblioteca");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1600, 1200);
        frame.setLocationRelativeTo(null); // Centraliza a janela

        // Caminho da imagem dentro do classpath
        String imagePath = "/images/azul.jpg";
        BackgroundPanel backgroundPanel = new BackgroundPanel(imagePath);
        backgroundPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel label = new JLabel("Escolha uma função:");
        label.setFont(new Font("Arial", Font.BOLD, 18));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 1;
        backgroundPanel.add(label, gbc);

        JButton cadastroButton = criarBotao("Cadastro de Livros");
        JButton clientesButton = criarBotao("Cadastro de Clientes");
        JButton autorButton = criarBotao("Cadastro de Autores");
        JButton editoraButton = criarBotao("Cadastro de Editora");
        JButton emprestimoButton = criarBotao("Registrar Empréstimo");
        JButton sairButton = criarBotao("Sair");

        backgroundPanel.add(cadastroButton, gbc);
        backgroundPanel.add(clientesButton, gbc);
        backgroundPanel.add(autorButton, gbc);
        backgroundPanel.add(editoraButton, gbc);
        backgroundPanel.add(emprestimoButton, gbc);
        backgroundPanel.add(sairButton, gbc);

        frame.setContentPane(backgroundPanel);

        cadastroButton.addActionListener(e -> new cadastroLivros());
        clientesButton.addActionListener(e -> new cadastroClientes(frame));
        autorButton.addActionListener(e -> new cadastroAutor(frame));
        editoraButton.addActionListener(e -> new cadastroEditora());
        emprestimoButton.addActionListener(e -> new emprestimoLivros(frame));
        sairButton.addActionListener(e -> System.exit(0));

        frame.setVisible(true);
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setPreferredSize(new Dimension(300, 50));
        botao.setFont(new Font("Arial", Font.PLAIN, 16));
        return botao;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(janelaPrincipal::new);
    }
}

// Painel de fundo corrigido para carregar a imagem corretamente usando getResource()
class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel(String imagePath) {
        try {
            // Carrega a imagem corretamente usando getResource()
            backgroundImage = ImageIO.read(getClass().getResource(imagePath));

            if (backgroundImage == null) {
                System.out.println("Imagem não encontrada: " + imagePath);
            }
        } catch (IOException | NullPointerException e) {
            System.out.println("Erro ao carregar a imagem: " + e.getMessage());
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
