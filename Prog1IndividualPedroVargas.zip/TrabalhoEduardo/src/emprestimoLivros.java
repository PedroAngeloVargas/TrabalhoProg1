import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/*Janela de emprestimos */
public class emprestimoLivros {
    private JFrame frame;
    private JTextField nomeCliente, tituloLivro, dataEmprestimo, dataDevolucao;
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton saveButton;
    private int selectedRow = -1;

    public emprestimoLivros(JFrame telaInicial) {
        frame = new JFrame("Empréstimo de Livros");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1600, 1200);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(7, 2));
        panel.add(new JLabel("Nome do Cliente:"));
        nomeCliente = new JTextField();
        panel.add(nomeCliente);

        panel.add(new JLabel("Título do Livro:"));
        tituloLivro = new JTextField();
        panel.add(tituloLivro);

        panel.add(new JLabel("Data de Empréstimo (DD/MM/AAAA):"));
        dataEmprestimo = new JTextField();
        formatarDataCampo(dataEmprestimo);
        panel.add(dataEmprestimo);

        panel.add(new JLabel("Data de Devolução (DD/MM/AAAA):"));
        dataDevolucao = new JTextField();
        formatarDataCampo(dataDevolucao);
        panel.add(dataDevolucao);

        JButton addButton = new JButton("Registrar Empréstimo");
        saveButton = new JButton("Salvar Edição");
        saveButton.setEnabled(false);
        JButton editButton = new JButton("Editar Empréstimo");
        JButton deleteButton = new JButton("Excluir Empréstimo");
        JButton voltarButton = new JButton("Voltar");

        panel.add(addButton);
        panel.add(saveButton);
        panel.add(editButton);
        panel.add(deleteButton);
        panel.add(voltarButton);

        tableModel = new DefaultTableModel(new Object[]{"Cliente", "Livro", "Data de Empréstimo", "Data de Devolução", "Valor"}, 0);
        table = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(table);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(tableScrollPane, BorderLayout.CENTER);

        addButton.addActionListener(e -> adicionarEmprestimo());
        editButton.addActionListener(e -> carregarDadosParaEdicao());
        saveButton.addActionListener(e -> salvarEdicao());
        deleteButton.addActionListener(e -> excluirEmprestimo());
        voltarButton.addActionListener(e -> {
            frame.dispose();
            telaInicial.setVisible(true);
        });

        frame.setVisible(true);
    }

    private void adicionarEmprestimo() {
        String nome = nomeCliente.getText();
        String titulo = tituloLivro.getText();
        String dataEmp = dataEmprestimo.getText();
        String dataDev = dataDevolucao.getText();

        if (!nome.isEmpty() && !titulo.isEmpty() && !dataEmp.isEmpty() && !dataDev.isEmpty()) {
            double valor = calcularValor(dataEmp, dataDev);
            tableModel.addRow(new Object[]{nome, titulo, dataEmp, dataDev, String.format("R$ %.2f", valor)});
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(frame, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDadosParaEdicao() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            nomeCliente.setText((String) tableModel.getValueAt(selectedRow, 0));
            tituloLivro.setText((String) tableModel.getValueAt(selectedRow, 1));
            dataEmprestimo.setText((String) tableModel.getValueAt(selectedRow, 2));
            dataDevolucao.setText((String) tableModel.getValueAt(selectedRow, 3));
            saveButton.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um empréstimo para editar!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void salvarEdicao() {
        if (selectedRow != -1) {
            String nome = nomeCliente.getText();
            String titulo = tituloLivro.getText();
            String dataEmp = dataEmprestimo.getText();
            String dataDev = dataDevolucao.getText();

            if (!nome.isEmpty() && !titulo.isEmpty() && !dataEmp.isEmpty() && !dataDev.isEmpty()) {
                double valor = calcularValor(dataEmp, dataDev);
                tableModel.setValueAt(nome, selectedRow, 0);
                tableModel.setValueAt(titulo, selectedRow, 1);
                tableModel.setValueAt(dataEmp, selectedRow, 2);
                tableModel.setValueAt(dataDev, selectedRow, 3);
                tableModel.setValueAt(String.format("R$ %.2f", valor), selectedRow, 4);
                limparCampos();
                saveButton.setEnabled(false);
                selectedRow = -1;
            } else {
                JOptionPane.showMessageDialog(frame, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void excluirEmprestimo() {
        selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir este empréstimo?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
                limparCampos();
                selectedRow = -1;
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Selecione um empréstimo para excluir!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    /*Cada semana são R$5,00. Esse é o calculo*/
    private double calcularValor(String dataEmp, String dataDev) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate emprestimo = LocalDate.parse(dataEmp, formatter);
            LocalDate devolucao = LocalDate.parse(dataDev, formatter);
            long dias = ChronoUnit.DAYS.between(emprestimo, devolucao);
            long semanas = dias / 7 + (dias % 7 != 0 ? 1 : 0);
            return semanas * 5.0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Datas inválidas! Use o formato DD/MM/AAAA.", "Erro", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    private void formatarDataCampo(JTextField campo) {
        campo.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ((!Character.isDigit(c) && c != '/') || campo.getText().length() >= 10) {
                    e.consume();
                }
            }
        });
    }

    private void limparCampos() {
        nomeCliente.setText("");
        tituloLivro.setText("");
        dataEmprestimo.setText("");
        dataDevolucao.setText("");
    }
}
