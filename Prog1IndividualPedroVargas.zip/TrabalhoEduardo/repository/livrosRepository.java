package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class livrosRepository {

    public void adicionarLivro(String titulo, String genero, String autor, int ano, String editora) {
        String sql = "INSERT INTO livros (titulo, genero, autor, ano, editora) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, titulo);
            stmt.setString(2, genero);
            stmt.setString(3, autor);
            stmt.setInt(4, ano);
            stmt.setString(5, editora);
            stmt.executeUpdate();

            System.out.println(" Livro adicionado com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao adicionar livro: " + e.getMessage());
        }
    }

    public List<String[]> listarLivros() {
        List<String[]> livros = new ArrayList<>();
        String sql = "SELECT * FROM livros";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                livros.add(new String[]{
                    rs.getString("titulo"),
                    rs.getString("genero"),
                    rs.getString("autor"),
                    String.valueOf(rs.getInt("ano")),
                    rs.getString("editora")
                });
            }

            System.out.println(" Lista de livros carregada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao listar livros: " + e.getMessage());
        }
        return livros;
    }

    public void atualizarLivro(int id, String titulo, String genero, String autor, int ano, String editora) {
        String sql = "UPDATE livros SET titulo = ?, genero = ?, autor = ?, ano = ?, editora = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, titulo);
            stmt.setString(2, genero);
            stmt.setString(3, autor);
            stmt.setInt(4, ano);
            stmt.setString(5, editora);
            stmt.setInt(6, id);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println(" Livro atualizado com sucesso!");
            } else {
                System.out.println("⚠️ Nenhum livro encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar livro: " + e.getMessage());
        }
    }

    public void excluirLivro(int id) {
        String sql = "DELETE FROM livros WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println(" Livro excluído com sucesso!");
            } else {
                System.out.println(" Nenhum livro encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao excluir livro: " + e.getMessage());
        }
    }
}
