package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class editoraRepository {

    public void adicionarEditora(String nomeFantasia, String razaoSocial, long cnpj, long inscricaoEstadual, String email, long telefone) {
        String sql = "INSERT INTO editoras (nomeFantasia, razaoSocial, cnpj, inscricaoEstadual, email, telefone) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nomeFantasia);
            stmt.setString(2, razaoSocial);
            stmt.setLong(3, cnpj);
            stmt.setLong(4, inscricaoEstadual);
            stmt.setString(5, email);
            stmt.setLong(6, telefone);
            stmt.executeUpdate();
            
            System.out.println(" Editora adicionada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao adicionar editora: " + e.getMessage());
        }
    }

    public List<String[]> listarEditoras() {
        List<String[]> editoras = new ArrayList<>();
        String sql = "SELECT * FROM editoras";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
             
            while (rs.next()) {
                editoras.add(new String[]{
                    String.valueOf(rs.getInt("id")),
                    rs.getString("nomeFantasia"),
                    rs.getString("razaoSocial"),
                    String.valueOf(rs.getLong("cnpj")),
                    String.valueOf(rs.getLong("inscricaoEstadual")),
                    rs.getString("email"),
                    String.valueOf(rs.getLong("telefone"))
                });
            }

            System.out.println(" Lista de editoras carregada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao listar editoras: " + e.getMessage());
        }
        return editoras;
    }

    public void atualizarEditora(int id, String nomeFantasia, String razaoSocial, long cnpj, long inscricaoEstadual, String email, long telefone) {
        String sql = "UPDATE editoras SET nomeFantasia = ?, razaoSocial = ?, cnpj = ?, inscricaoEstadual = ?, email = ?, telefone = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nomeFantasia);
            stmt.setString(2, razaoSocial);
            stmt.setLong(3, cnpj);
            stmt.setLong(4, inscricaoEstadual);
            stmt.setString(5, email);
            stmt.setLong(6, telefone);
            stmt.setInt(7, id);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println(" Editora atualizada com sucesso!");
            } else {
                System.out.println(" Nenhuma editora encontrada com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar editora: " + e.getMessage());
        }
    }

    public void excluirEditora(int id) {
        String sql = "DELETE FROM editoras WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println(" Editora excluída com sucesso!");
            } else {
                System.out.println(" Nenhuma editora encontrada com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao excluir editora: " + e.getMessage());
        }
    }
}
