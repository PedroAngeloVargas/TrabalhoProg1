package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class clienteRepository {

    public void adicionarCliente(String nome, long cpf, Date dataNascimento, long telefone, String email, int cep, String cidade, String uf, String rua, String bairro, int numero, String complemento) {
        String sql = "INSERT INTO clientes (nome, cpf, data_nascimento, telefone, email, cep, cidade, uf, rua, bairro, numero, complemento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nome);
            stmt.setLong(2, cpf);
            stmt.setDate(3, dataNascimento);
            stmt.setLong(4, telefone);
            stmt.setString(5, email);
            stmt.setInt(6, cep);
            stmt.setString(7, cidade);
            stmt.setString(8, uf);
            stmt.setString(9, rua);
            stmt.setString(10, bairro);
            stmt.setInt(11, numero);
            stmt.setString(12, complemento);
            stmt.executeUpdate();
            
            System.out.println(" Cliente adicionado com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao adicionar cliente: " + e.getMessage());
        }
    }

    public List<String[]> listarClientes() {
        List<String[]> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
             
            while (rs.next()) {
                clientes.add(new String[]{
                    rs.getString("nome"),
                    String.valueOf(rs.getLong("cpf")),
                    rs.getDate("data_nascimento").toString(),
                    String.valueOf(rs.getLong("telefone")),
                    rs.getString("email"),
                    String.valueOf(rs.getInt("cep")),
                    rs.getString("cidade"),
                    rs.getString("uf"),
                    rs.getString("rua"),
                    rs.getString("bairro"),
                    String.valueOf(rs.getInt("numero")),
                    rs.getString("complemento")
                });
            }

            System.out.println(" Lista de clientes carregada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao listar clientes: " + e.getMessage());
        }
        return clientes;
    }

    public void atualizarCliente(int id, String nome, long cpf, Date dataNascimento, long telefone, String email, int cep, String cidade, String uf, String rua, String bairro, int numero, String complemento) {
        String sql = "UPDATE clientes SET nome = ?, cpf = ?, data_nascimento = ?, telefone = ?, email = ?, cep = ?, cidade = ?, uf = ?, rua = ?, bairro = ?, numero = ?, complemento = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nome);
            stmt.setLong(2, cpf);
            stmt.setDate(3, dataNascimento);
            stmt.setLong(4, telefone);
            stmt.setString(5, email);
            stmt.setInt(6, cep);
            stmt.setString(7, cidade);
            stmt.setString(8, uf);
            stmt.setString(9, rua);
            stmt.setString(10, bairro);
            stmt.setInt(11, numero);
            stmt.setString(12, complemento);
            stmt.setInt(13, id);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println(" Cliente atualizado com sucesso!");
            } else {
                System.out.println(" Nenhum cliente encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar cliente: " + e.getMessage());
        }
    }

    public void excluirCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println(" Cliente excluído com sucesso!");
            } else {
                System.out.println(" Nenhum cliente encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao excluir cliente: " + e.getMessage());
        }
    }
}
