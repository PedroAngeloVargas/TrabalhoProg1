package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class autorRepository {

    public void adicionarAutor(String nome, String nacionalidade) {
        String sql = "INSERT INTO autores (nome, nacionalidade) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nome);
            stmt.setString(2, nacionalidade);
            stmt.executeUpdate();
            System.out.println(" Autor adicionado com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao adicionar autor: " + e.getMessage());
        }
    }

    public List<String[]> listarAutores() {
        List<String[]> autores = new ArrayList<>();
        String sql = "SELECT * FROM autores";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                autores.add(new String[]{
                    String.valueOf(rs.getInt("id")),
                    rs.getString("nome"),
                    rs.getString("nacionalidade")
                });
            }
            System.out.println(" Lista de autores carregada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao listar autores: " + e.getMessage());
        }
        return autores;
    }

    public void atualizarAutor(int id, String nome, String nacionalidade) {
        String sql = "UPDATE autores SET nome = ?, nacionalidade = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nome);
            stmt.setString(2, nacionalidade);
            stmt.setInt(3, id);
            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                System.out.println(" Autor atualizado com sucesso!");
            } else {
                System.out.println(" Nenhum autor encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar autor: " + e.getMessage());
        }
    }

    public void excluirAutor(int id) {
        String sql = "DELETE FROM autores WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println(" Autor excluído com sucesso!");
            } else {
                System.out.println("⚠️ Nenhum autor encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao excluir autor: " + e.getMessage());
        }
    }
}
