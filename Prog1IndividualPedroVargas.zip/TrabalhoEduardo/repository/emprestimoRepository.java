package repository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class emprestimoRepository {

    public void adicionarEmprestimo(String nomeCliente, String tituloLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, double valor) {
        String sql = "INSERT INTO emprestimos (nomeCliente, tituloLivro, dataEmprestimo, dataDevolucao, valor) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nomeCliente);
            stmt.setString(2, tituloLivro);
            stmt.setDate(3, Date.valueOf(dataEmprestimo));
            stmt.setDate(4, Date.valueOf(dataDevolucao));
            stmt.setDouble(5, valor);
            stmt.executeUpdate();
            
            System.out.println(" Empréstimo registrado com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao registrar empréstimo: " + e.getMessage());
        }
    }

    public List<String[]> listarEmprestimos() {
        List<String[]> emprestimos = new ArrayList<>();
        String sql = "SELECT * FROM emprestimos";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
             
            while (rs.next()) {
                emprestimos.add(new String[]{
                    String.valueOf(rs.getInt("id")),
                    rs.getString("nomeCliente"),
                    rs.getString("tituloLivro"),
                    rs.getDate("dataEmprestimo").toString(),
                    rs.getDate("dataDevolucao").toString(),
                    String.format("R$ %.2f", rs.getDouble("valor"))
                });
            }

            System.out.println(" Lista de empréstimos carregada com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro ao listar empréstimos: " + e.getMessage());
        }
        return emprestimos;
    }

    public void atualizarEmprestimo(int id, String nomeCliente, String tituloLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, double valor) {
        String sql = "UPDATE emprestimos SET nomeCliente = ?, tituloLivro = ?, dataEmprestimo = ?, dataDevolucao = ?, valor = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nomeCliente);
            stmt.setString(2, tituloLivro);
            stmt.setDate(3, Date.valueOf(dataEmprestimo));
            stmt.setDate(4, Date.valueOf(dataDevolucao));
            stmt.setDouble(5, valor);
            stmt.setInt(6, id);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println(" Empréstimo atualizado com sucesso!");
            } else {
                System.out.println(" Nenhum empréstimo encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar empréstimo: " + e.getMessage());
        }
    }

    public void excluirEmprestimo(int id) {
        String sql = "DELETE FROM emprestimos WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println(" Empréstimo excluído com sucesso!");
            } else {
                System.out.println(" Nenhum empréstimo encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.err.println(" Erro ao excluir empréstimo: " + e.getMessage());
        }
    }
}
